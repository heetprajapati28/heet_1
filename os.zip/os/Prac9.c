#include <sys/ipc.h> 

#include <sys/shm.h> 

#include <stdio.h> 

#include <stdlib.h> 

#include <unistd.h> 

#include <string.h> 

int main(){ 

  

    key_t key = ftok("shmfile",65); 

     

    int shmid = shmget(key,1024,0666|IPC_CREAT); 

     

    int* sum = (int*) shmat(shmid,(void*)0,0); 

    int counter=0; 

    int pid = fork(); 

    if(pid==0){ 

    for(int i=1;i<=50;i++){ 

    counter+=i; 

    } 

    printf("Sum 1 to 50 by child is: %d\n", counter); 

    *sum=*sum+counter; 

    printf("Shared memory sum is: %d\n", *sum); 

    } 

    else{ 

    for(int j=51;j<=100;j++){ 

    counter+=j; 

    } 

    printf("Sum 51 to 100 by parent is: %d\n", counter); 

    *sum=*sum+counter; 

    } 

    //detach from shared memory 

    shmdt(sum); 

    // destroy the shared memory 

    shmctl(shmid,IPC_RMID,NULL); 

} 