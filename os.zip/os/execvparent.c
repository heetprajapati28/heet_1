#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
int p;
printf("\nPID of parent = %d ",getpid());
p=fork();
if(p==-1)
   	{
	printf("\nThere is an error\n ");
	}
if(p==0)
	{
	printf("\nchild process is running ..");
	printf("\nNow execv will call child.c from child process");
								
	char *args[]={"1234",NULL};
	execv("./execvchild",args);
	}
else{
printf("\nNow parent is running \n");
    }
}
