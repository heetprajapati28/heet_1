echo "first file name "
read file1
echo "second file name "
read file2

cmp $file1 $file2 > error

total=`wc -c error | cut -f 7 -d " "`
echo $total

if [ $total -eq 0 ]
then
        echo "Both file are same"else
        echo "Both file are not same"
fi