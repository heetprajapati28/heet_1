#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
printf("\n hello world");
printf("\nThe PID of child = %d",getpid());
printf("\n %s",*argv);
}
