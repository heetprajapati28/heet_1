//d20ce166
#include<stdio.h>
void findWaitingTime(int processes[] ,int n,int burstTime[],int waitingTime[])
{

    waitingTime[0]=0;

    for(int i=1; i<n; i++)
    {
       waitingTime[i]=burstTime[i-1]+waitingTime[i-1];
    }

}

void findTurnAroundTime(int processes[] ,int n,int burstTime[],int waitingTime[],int turnTime[])
{
       for(int i=0;i<n;i++)
       {
           turnTime[i]=burstTime[i]+waitingTime[i];
       }
}

void findAverageTime(int processes[],int n ,int burstTime[])
{
        int waitingTime[n],turnTime[n],total_wt=0,total_tat=0;
        
        findWaitingTime(processes ,n , burstTime, waitingTime);
        
        findTurnAroundTime(processes ,n , burstTime , waitingTime , turnTime);
        
        printf("Processes Burst Time Waiting Time Turn Around Time\n");
        for(int i=0;i<n;i++)
        {
        total_wt=total_wt+waitingTime[i];
        total_tat=total_tat+turnTime[i];
        printf("%d\t\t|",(i+1));
        printf("%d\t\t|",burstTime[i]);
        printf("%d\t\t|",waitingTime[i]);
        printf("%d\n|",turnTime[i]);
        
        }
        int s=(float)total_wt/(float)n;
        int t=(float)total_tat/(float)n;
        printf("Average waiting time=%d",s);
        printf("\n");
        printf("Average turn around time=%d",t);
        
}
int main()
{
int processes[]={1,2,3};
int n =sizeof processes/sizeof processes[0];
int burstTime[]={10,5,8};
findAverageTime(processes,n,burstTime);
return 0;
}

