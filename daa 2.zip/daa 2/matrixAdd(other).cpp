#include <iostream>
using namespace std;
int main()
{
    int cnt = 0;
    int size1;
loop:
    cout << "Enter the size of 1st MATRIX :- ";
    cin >> size1;
    int matrix1[size1][size1];
    cout << "\nEnter the elements of 1st matrix\n";
    cnt += 2;
    for (int i = 0; i < size1; i++)
    {
        cnt += 4;
        cout << "Enter the elements of row " << i + 1 << "\n";
        for (int j = 0; j < size1; j++)
        {
            cnt += 2;
            cin >> matrix1[i][j];
        }
    }
    int size2;
    cout << "Enter the size of 2nd MATRIX :- ";
    cin >> size2;
    cnt++;
    if (size1 != size2)
    {
        cout << "The size of matrix are not equal\n";
        goto loop;
    }
    int matrix2[size2][size2];
    cout << "\nEnter the elements of 2nd matrix\n";
    cnt += 2;
    for (int i = 0; i < size2; i++)
    {
        cnt += 4;
        cout << "Enter the elements of row " << i + 1 << "\n";
        for (int j = 0; j < size2; j++)
        {
            cnt += 2;
            cin >> matrix2[i][j];
        }
    }
    int add[size1][size1];
    cnt += 2;

    for (int i = 0; i < size1; i++)
    {
        cnt += 4;
        for (int j = 0; j < size1; j++)
        {
            cnt += 2;
            add[i][j] = matrix1[i][j] + matrix2[i][j];
        }
        cout << endl;
    }
    cout << "\nThe Addition of two matrix are:-\n";
    cnt += 2;
    for (int i = 0; i < size1; i++)
    {
        cnt += 4;
        for (int j = 0; j < size1; j++)
        {
            cnt += 2;
            cout << add[i][j] << " ";
        }
        cout << endl;
    }
    cout << "For Matrix size=" << size1 << " counter variable ran for " << cnt << endl;
}
