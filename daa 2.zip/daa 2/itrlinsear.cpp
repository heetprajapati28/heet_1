#include<iostream>
using namespace std;

int c=0,f=0,n;


void itr_lin_sear(int a[],int key){
    c++; //i=0
    c++; //i<n
    for(int i=0;i<n;i++){
        c++; //if
        if(a[i]==key){
            c+=1; //f=1
            f=1;
            return;
        }
        c+=2; //i++ and i<n
    }
    return;
}

main(){
    int key;
    cout<<"Enter size of array : ";
    cin>>n;

    int a[n];

    cout<<"\nEnter the elements in array : ";
    for(int i=0;i<n;i++){
        cin>>a[i];
    }

    cout<<"\nTo search ? ";
    cin>>key;

    itr_lin_sear(a,key);

    if(f==0){
        cout<<"\nNot Found";
    }
    else{
        cout<<"\nFound";
    }
    cout<<"\nThe number of operations : "<<c<<"\n";
}


