
find . -empty