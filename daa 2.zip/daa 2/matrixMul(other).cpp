#include <iostream>
using namespace std;
int main()
{
    int cnt = 0;
    int size1;
loop:
    cout << "Enter the size of 1st MATRIX :- ";
    cin >> size1;
    int matrix1[size1][size1];
    cout << "\nEnter the elements of 1st matrx\n";
    for (int i = 0; i < size1; i++)
    {
        cout << "Enter the elements of row " << i + 1 << "\n";
        for (int j = 0; j < size1; j++)
            cin >> matrix1[i][j];
    }
    int size2;
    cout << "Enter the size of 2nd MATRIX :- ";
    cin >> size2;
    cnt++;
    if (size1 != size2)
    {
        cout << "The size of matrix are not equal\n";
        goto loop;
    }
    int matrix2[size2][size2];
    cout << "\nEnter the elements of 2nd matrix\n";
    for (int i = 0; i < size2; i++)
    {
        cout << "Enter the elements of row " << i + 1 << "\n";
        for (int j = 0; j < size2; j++)
            cin >> matrix2[i][j];
    }
    int mul[size1][size1];
    cnt += 2;
    for (int i = 0; i < size1; i++)
    {
        cnt += 4;
        int sum = 0;
        for (int j = 0; j < size1; j++)
        {
            cnt += 4;
            mul[i][j] = 0;
            for (int k = 0; k < size1; k++)
            {
                cnt += 2;
                mul[i][j] = mul[i][j] + matrix1[i][k] * matrix2[k][j];
            }
        }
    }
    cout << "\nThe Multiplication of two matrix are:-\n";
    for (int i = 0; i < size1; i++)
    {
        for (int j = 0; j < size1; j++)
        {
            cout << mul[i][j] << " ";
        }
        cout << endl;
    }
    cout << "For Matrix size=" << size1 << " counter variable ran for " << cnt ;
}
