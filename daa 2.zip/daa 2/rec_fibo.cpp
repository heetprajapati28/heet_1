#include<iostream>
using namespace std;
int c=0;
int fib(int n) {
    c++;
   if (n <= 1)
   return n;
   return fib(n-1) + fib(n-2);
}
int main () {
    int n;
    cout<<"\nEnter number :";
   cin>>n;
   for(int i=0;i<n;i++)
   cout<<fib(i)<<" ";
   cout<<"\n\n"<<"No of operations : "<<c;
   return 0;
}
