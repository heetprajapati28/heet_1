#include<iostream>

using namespace std;
int cnt=0;
int binarysearch(int *a,int n,int e)
{
    int l,h,m;
    l=0;
    h=n-1;
	cnt=cnt+2;//l and h
	cnt++;//l<=h
    while(l<=h)
    {

        m=(l+h)/2;
        cnt++;//m
        cnt++;//first if
        if(e==a[m]){
            cnt++;//return
			return(m);

        }else{
				cnt++;//if
            if(e>a[m]){
                l=m+1;
				cnt++;}//l
            else{
                h=m-1;
				cnt++;
				}
				//h
			}
	cnt++;//l<=h

    }

    return -1;
}

int main()
{
    int n,i,e,result;
    int choice;
    cout<<"How Many Elements:";
    cin>>n;
    cout<<"\nElements of Array in Ascending order\n";
    int a[n];
    for(i=0;i<n;++i)
    {
        a[i]=i+1;
        cout<<" "<<a[i];
    }

    cout<<"\nEnter element to search:";
    cin>>e;

    result=binarysearch(a,n,e);

    if(result!=-1)
        {cout<<"\nElement found at position "<<result+1;
        cout<<"\nnumber of operations: "<<cnt;}
    else
        cout<<"\nElement is not found....!!!";

}
