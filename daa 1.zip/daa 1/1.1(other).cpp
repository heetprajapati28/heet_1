#include <iostream>
#include <math.h>
using namespace std;
void checker(int input[], int size)
{
    for (int i = 0; i < size; i++)
    {
        float time_by_machineA = pow(2, input[i]) * pow(10, -4);
        float time_by_machineB = pow(2, input[i]) * pow(10, -6);
        float time_by_machineC = pow(input[i], 3) * pow(10, -2);
        cout << "\nTime by machine A for input size=" << input[i] << " = " << time_by_machineA << " sec." << endl;
        cout << "Time by machine B for input size=" << input[i] << " = " << time_by_machineB << "sec." << endl;
        cout << "Time by machine C for input size=" << input[i] << " = " << time_by_machineC << "sec." << endl;
        cout<<"\n";
        if (time_by_machineA < time_by_machineB && time_by_machineA < time_by_machineC)
            cout << "For input size=" << input[i] << " Machine A is best.\n";
        if (time_by_machineB < time_by_machineA && time_by_machineB < time_by_machineC)
            cout << "For input size=" << input[i] << " Machine B is best.\n";
        else
            cout << "For input size=" << input[i] << " Machine C is best.\n";
        cout << "For input size=" << input[i];
        if (time_by_machineC < time_by_machineA)
            cout << " Machine C is faster than Machine A by " << time_by_machineA - time_by_machineC << "sec.\n";
        else
            cout << " Machine A is faster than Machine C by " << time_by_machineC - time_by_machineA << "sec.\n";
    }
}
int main()
{
    int input[5] = {10, 15, 20, 25, 30};
    checker(input, 5);
}
