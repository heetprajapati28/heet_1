#!/bin/bash
echo "Enter name of file 1:"
read file1

echo "Enter name of file 2:"
read file2

if diff -u $file1 $file2
then
	echo "Same files"
	rm $file2
else
	echo "Different files"
	echo "The changes required are mentioned above:"
fi


